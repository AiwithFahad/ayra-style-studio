<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep AYRA as three first-class routes (`/`, `/stylist`, `/try-on`) sharing one mobile-first shell, because each core workflow must remain directly addressable.
- Keep all AYRA product routes under the authenticated layout and access wardrobe data through user-scoped policies, because wardrobe records and photos are private per account.
- Keep wardrobe selection as shared client state derived from the user-scoped wardrobe hook, because both catalogue management and try-on must use the same current items.
- Derive product-page and storefront displays from the private wardrobe hook, because wardrobe records remain the single source of truth.

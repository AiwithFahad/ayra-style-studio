# AYRA Phase 1

- [x] Build the wardrobe catalogue with category and colour labels
- [x] Add local photo upload interaction
- [x] Build the three-look stylist experience with placeholder suggestions
- [x] Build the live-camera try-on experience with a selected outfit
- [x] Apply the mobile-first editorial design across all screens
- [x] Verify every screen in the live preview

# Private accounts

- [x] Enable email and password accounts
- [x] Require sign-in for all three AYRA screens
- [x] Store wardrobe records and photos privately per account
- [x] Verify signed-out visitors are redirected to the account screen
- [x] Verify sign-in, upload, and sign-out after the first user confirms their email

# Responsive wardrobe and try-on upgrade

- [x] Add 3 men's summer shirts, 3 kids' shirts, and 3 kids' jackets
- [x] Make wardrobe filters and item management functional
- [x] Add direct wardrobe item selection to virtual try-on
- [x] Expand and verify responsive layouts across phone, tablet, laptop, and desktop

# Style Me category selection

- [x] Add functional Men Jackets, Men Shirts, Kids Jackets, and Kids Shirts views
- [x] Let users select and preview compatible items in Style Me
- [x] Carry selected Style Me items into AI Try-On reliably
- [x] Verify every category and men/kids compatibility end to end

# Homepage storefront presentation

- [x] Add premium hero and three animated product carousels
- [x] Preserve and integrate the complete wardrobe catalogue
- [x] Add About, Latest Drop, Testimonials, Contact, and footer
- [x] Add a detail page for every wardrobe piece with Buy Now and Try It On
- [x] Verify all links, controls, and responsive layouts

# Reference-led storefront redesign

- [x] Add the compact retail header and reference-inspired hero
- [x] Add featured collections, product showcase, articles, and store information
- [x] Preserve wardrobe actions and product Try It On handoff
- [x] Verify phone, tablet, desktop, and ultra-wide layouts

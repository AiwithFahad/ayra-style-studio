# AYRA responsive wardrobe and try-on upgrade

## What will change

- Preserve the existing 3 men’s jackets and current 3 men’s shirts exactly as they are.
- Create and add 9 new private wardrobe pieces for the current account:
  - 3 men’s summer shirts
  - 3 kids’ shirts
  - 3 kids’ jackets
- Keep all clothing photography cohesive with AYRA’s editorial catalogue style.

## Wardrobe

- Turn **All, Men, Kids, Shirts, Jackets** into working filters with active states and accurate visible counts.
- Make the catalogue adapt from a compact mobile grid to wider tablet and desktop grids.
- Keep upload, newest-first ordering, image loading, category labels, and colour labels working.
- Add practical item controls so an uploaded piece can be removed and its category can be corrected when AI classification is wrong.
- Add clear empty, loading, error, upload-processing, and filtered-empty states.

## AI Stylist and Try-On

- Keep the existing AI stylist rules and generation flow intact.
- Expand Try-On so users can choose any compatible wardrobe item directly, not only a previously generated stylist look:
  - choose a men’s or kids’ shirt
  - optionally add a jacket from the same category group
  - prevent men’s and kids’ items from being mixed
- Keep stylist suggestions available as quick selections.
- Preserve camera, uploaded photo, short-video frame extraction, streaming generation, Save, and Retry.
- Refine the selector, input/result comparison, actions, loading states, and messages for all screen sizes.

## Responsive UI

- Expand the shared AYRA shell beyond the current phone-width frame while preserving the existing editorial design.
- Use mobile-first layouts that become denser on tablet, laptop, and desktop without stretched cards or overlapping controls.
- Improve navigation, headers, spacing, touch targets, item cards, outfit cards, and fixed mobile navigation.
- Check phone, tablet, laptop, and desktop widths in the running app.

## Verification

- Confirm all 15 pieces appear privately for the current account: 6 men’s shirts, 3 men’s jackets, 3 kids’ shirts, and 3 kids’ jackets.
- Verify each wardrobe filter, upload/category correction/delete flow, stylist cards, direct item selection, compatibility rules, and all three try-on input methods.
- Verify the app at mobile, tablet, laptop, and desktop sizes and resolve any build or runtime errors.

## Technical details

- Continue using the existing private wardrobe storage and user-scoped database policies.
- Store generated catalogue images in the existing private wardrobe collection and insert matching records under the current user.
- Keep AI calls server-side and preserve the existing image-generation endpoint and model.
- Record any new structural decisions in the project’s architecture notes.

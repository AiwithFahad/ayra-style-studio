# Style Me category selection

## Build
- Add four working category views to Style Me: Men Shirts, Men Jackets, Kids Shirts, and Kids Jackets, each sourced from the signed-in user's current wardrobe.
- Show the correct item photos, names, colours, counts, and clear selected states in each category.
- Let users build a valid look by choosing a men's or kids' shirt and an optional jacket from the same group; prevent men/kids mixing.
- Preview the selected pieces in Style Me and open AI Try-On with that exact selection.
- Keep the existing AI-generated three-look feature and its cards unchanged alongside the new manual selection flow.

## Try-On connection
- Resolve item IDs passed from Style Me against the current private wardrobe, even when the selection was not one of the saved AI suggestions.
- Display the carried-over shirt and optional jacket immediately and keep all camera, photo, video, Save, and Retry actions working.

## Verification
- Check all four category views contain the correct items and counts.
- Check men and kids jackets only pair with their matching shirts.
- Check shirt-only and shirt-plus-jacket selections arrive in Try-On with the correct preview at phone and desktop sizes.
- Confirm the preview builds without errors.

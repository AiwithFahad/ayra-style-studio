# AYRA Homepage and Product Pages

## What will change

- Redesign only the authenticated homepage into the requested sequence: premium fashion hero, three animated product carousels, the existing wardrobe/category area, About Us, The Latest Drop, Testimonials, Contact, and footer.
- Preserve the current wardrobe heading, counts, navigation, filters, upload, category editing, deletion, private images, and newest-first ordering.
- Use the current 15 private wardrobe pieces throughout the homepage; no products or user data will be replaced.
- Add a responsive detail page for every wardrobe item with its current image, name, category, colour, a displayed price, Buy Now, and a Try It On action directly below it.
- Connect Try It On to the existing AI try-on page. Shirts open directly; jackets automatically pair with a compatible shirt because AYRA’s try-on rules require a shirt base.

## Interaction and layout

- Carousels will support touch dragging, keyboard navigation, and visible previous/next controls, with lightweight depth and motion that respects reduced-motion settings.
- Product cards in carousels, Latest Drop, and the wardrobe grid will open the matching product detail page without interfering with edit or delete controls.
- Mobile will use edge-to-edge editorial sections and stacked actions; tablet and desktop will progressively expand product visibility and section spacing.
- Contact will be presentation-only contact information/linking so no new backend or submission behavior is introduced.

## Technical details

- Keep `/`, `/stylist`, and `/try-on` under the existing authenticated shell and add `/product/$id` under that same protected layout.
- Reuse the existing wardrobe hook and signed private image URLs; no database, storage, AI, authentication, or purchase logic changes.
- Add shared product presentation helpers/components where needed, plus route-specific metadata for the new detail route.
- Since AYRA currently has no checkout or stored prices, Buy Now will remain a clearly labeled presentation action rather than introducing unrequested commerce logic. Display prices will be UI-only category-based values.
- Verify the homepage order, all 15 detail links, direct try-on handoff, carousel controls, and responsive layouts in the running preview.

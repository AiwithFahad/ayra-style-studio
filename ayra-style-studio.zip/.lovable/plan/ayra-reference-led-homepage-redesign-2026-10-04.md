# AYRA Reference-Led Homepage Redesign

## What will change

- Restyle the authenticated AYRA homepage around the uploaded fashion-store reference: compact retail header, image-led hero, tighter product merchandising, editorial story bands, collection tiles, article cards, contact information, and a structured footer.
- Keep every existing wardrobe item and all wardrobe actions unchanged: filters, counts, uploads, category edits, deletion, private images, newest-first ordering, and product-detail links.
- Preserve Wardrobe, Stylist, and Try-on navigation and add responsive search, account, saved-items, and bag controls as presentation/navigation controls without inventing checkout or account-management systems.
- Keep product detail pages connected to the same private wardrobe records, with Buy Now and the working Try It On action directly beneath it.

## Page order

1. Compact AYRA storefront header and mobile navigation
2. Premium fashion hero using an existing wardrobe image
3. Featured shirt carousel with lightweight depth and touch controls
4. Functional Shop by Category wardrobe catalogue
5. About AYRA editorial image-and-copy story
6. Latest Drop using newest wardrobe pieces
7. Featured Collections using real wardrobe imagery
8. Product Showcase using all existing wardrobe items
9. Customer Testimonials
10. Latest News and Articles
11. Contact and store-style information
12. Multi-column footer with navigation, policies, social links, and contact details

## Responsive and interaction details

- Match the reference’s compact spacing, restrained card treatment, strong image proportions, simple black/ink controls, and clean editorial rhythm while retaining AYRA’s existing typography and cool-muted identity.
- Use horizontal touch scrolling and subtle perspective only where it improves browsing; respect reduced-motion settings.
- Keep product cards linked to their correct detail pages across every carousel, grid, and collection.
- Adapt navigation and dense product sections for phone, tablet, laptop, desktop, and ultra-wide screens without hiding core workflows.

## Technical details

- Change frontend presentation only; no database, storage, authentication, AI, camera, wardrobe, pricing, or checkout logic changes.
- Derive all commerce-style product displays from the existing private wardrobe hook and signed image URLs.
- Reuse existing buttons, route links, and product helpers; add small focused homepage components only where useful.
- Verify the complete page order, category actions, representative product links, carousel controls, product Try It On handoff, and responsive layouts in the running preview.

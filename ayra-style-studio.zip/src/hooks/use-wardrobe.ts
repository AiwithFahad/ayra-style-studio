import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { WardrobeItem } from "@/lib/wardrobe-data";

type WardrobeState = {
  items: WardrobeItem[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
};

export function useWardrobe(): WardrobeState {
  const [items, setItems] = useState<WardrobeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error: queryError } = await supabase
      .from("wardrobe_items")
      .select("id, name, category, colour, image_url")
      .order("created_at", { ascending: false });

    if (queryError) {
      setError(queryError.message);
      setLoading(false);
      return;
    }

    const rows = data ?? [];
    const paths = rows.map((row) => row.image_url);
    const { data: signed } = paths.length
      ? await supabase.storage.from("wardrobe").createSignedUrls(paths, 3600)
      : { data: [] };

    setItems(rows.map((row, index) => ({
      id: row.id,
      name: row.name,
      category: row.category as WardrobeItem["category"],
      colour: row.colour,
      image: signed?.[index]?.signedUrl ?? "",
      storagePath: row.image_url,
    })));
    setLoading(false);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return { items, loading, error, refresh };
}
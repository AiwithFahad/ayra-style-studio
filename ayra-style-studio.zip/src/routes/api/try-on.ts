import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { editImage } from "@/lib/image-gateway.server";

const PROMPT = `Virtual try-on. Image 1 is the subject photo. The following images are clothing items from the user's wardrobe.
Dress the person in image 1 in exactly these clothing items (a shirt, and a jacket worn over it if provided), matching each garment's colour, fabric, pattern and details from its photo.
Keep the person's face, identity, hair, skin tone, body shape, pose, expression, camera angle, lighting and the entire background exactly the same. Change only the clothing on the upper body. Photorealistic result with natural fit, folds and shadows.`;

export const Route = createFileRoute("/api/try-on")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const token = request.headers.get("authorization")?.replace("Bearer ", "");
        const url = process.env["SUPABASE_URL"];
        const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
        if (!token || !url || !key) return new Response("Please sign in again.", { status: 401 });
        const supabase = createClient(url, key, { auth: { persistSession: false } });
        const { data, error } = await supabase.auth.getUser(token);
        if (error || !data.user) return new Response("Please sign in again.", { status: 401 });

        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) return new Response("AI is not configured.", { status: 500 });

        const incoming = await request.formData();
        const images = incoming.getAll("image[]").filter((v): v is File => v instanceof File);
        if (images.length < 2 || images.length > 3) return new Response("A subject photo and outfit pieces are required.", { status: 400 });
        if (images.some((f) => f.size > 10 * 1024 * 1024)) return new Response("Images must be under 10MB.", { status: 400 });

        const form = new FormData();
        for (const img of images) form.append("image[]", img);
        form.set("prompt", PROMPT);
        form.set("quality", "high");
        const stream = incoming.get("stream");
        if (typeof stream === "string") form.set("stream", stream);

        const upstream = await editImage(apiKey, form);
        return new Response(upstream.body, {
          status: upstream.status,
          headers: {
            "Content-Type": upstream.headers.get("Content-Type") ?? "application/json",
            "Cache-Control": "no-cache",
          },
        });
      },
    },
  },
});

import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Check, Loader2, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { useWardrobe } from "@/hooks/use-wardrobe";
import { styleMe, type StylistOutfit } from "@/lib/stylist.functions";
import type { WardrobeItem } from "@/lib/wardrobe-data";

type StyleCategory = WardrobeItem["category"];

const STYLE_CATEGORIES: { category: StyleCategory; label: string }[] = [
  { category: "Men shirt", label: "Men Shirts" },
  { category: "Men jacket", label: "Men Jackets" },
  { category: "Kid shirt", label: "Kids Shirts" },
  { category: "Kid jacket", label: "Kids Jackets" },
];

export const Route = createFileRoute("/_authenticated/stylist")({
  head: () => ({ meta: [
    { title: "AI Stylist — AYRA" },
    { name: "description", content: "Discover three considered outfit combinations from your AYRA wardrobe." },
    { property: "og:title", content: "AI Stylist — AYRA" },
    { property: "og:description", content: "Three thoughtful looks composed from clothes you already own." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: StylistPage,
});

function StylistPage() {
  const { items, loading } = useWardrobe();
  const runStylist = useServerFn(styleMe);
  const [outfits, setOutfits] = useState<StylistOutfit[] | null>(null);
  const [styling, setStyling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<StyleCategory>("Men shirt");
  const [selectedShirtId, setSelectedShirtId] = useState<string | null>(null);
  const [selectedJacketId, setSelectedJacketId] = useState<string | null>(null);
  const hasShirt = items.some((item) => item.category.endsWith("shirt"));
  const byId = new Map(items.map((item) => [item.id, item]));
  const categoryItems = useMemo(() => items.filter((item) => item.category === activeCategory), [activeCategory, items]);
  const selectedShirt = items.find((item) => item.id === selectedShirtId && item.category.endsWith("shirt"));
  const selectedJacket = items.find((item) => item.id === selectedJacketId && item.category.endsWith("jacket"));
  const selectedGroup = selectedShirt?.category.split(" ")[0];
  const validJacket = selectedJacket?.category === `${selectedGroup} jacket` ? selectedJacket : undefined;
  const selectedPieces = selectedShirt ? (validJacket ? [selectedShirt, validJacket] : [selectedShirt]) : [];

  function selectItem(item: WardrobeItem) {
    const group = item.category.split(" ")[0];
    if (item.category.endsWith("shirt")) {
      setSelectedShirtId(item.id);
      if (selectedJacket?.category !== `${group} jacket`) setSelectedJacketId(null);
      return;
    }
    const matchingShirt = selectedShirt?.category === `${group} shirt`
      ? selectedShirt
      : items.find((candidate) => candidate.category === `${group} shirt`);
    if (matchingShirt) setSelectedShirtId(matchingShirt.id);
    setSelectedJacketId(item.id);
  }

  async function handleStyle() {
    setStyling(true);
    setError(null);
    try {
      const result = await runStylist();
      setOutfits(result.outfits);
      localStorage.setItem("ayra:outfits", JSON.stringify(result.outfits));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    }
    setStyling(false);
  }

  return (
    <AppShell eyebrow="Personal edit · this week" title="A considered edit" note={`${items.length} pieces · ${outfits?.length ?? 0} new looks`}>
      <section className="rounded-md bg-card/80 p-5 ring-1 ring-border sm:p-6">
        <p className="font-display text-[22px] leading-tight">Three looks, chosen from what you already own.</p>
        <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">AYRA looks at every photo, balancing colour harmony and formality.</p>
        <Button onClick={handleStyle} disabled={styling || loading || !hasShirt} className="mt-5 w-full">
          {styling ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />} {styling ? "Styling your wardrobe" : outfits ? "Style me again" : "Style me"}
        </Button>
        {error && <p role="alert" className="mt-3 text-xs text-destructive">{error}</p>}
      </section>

      <section className="mt-6 rounded-md bg-card/70 p-4 ring-1 ring-border sm:p-5">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3">
          <div className="min-w-0">
            <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-accent">Wardrobe collections</p>
            <h2 className="mt-1 font-display text-xl">Build your own look</h2>
          </div>
          <span className="shrink-0 text-[10px] text-muted-foreground">{categoryItems.length} pieces</span>
        </div>

        <div role="tablist" aria-label="Style Me categories" className="mt-4 grid grid-cols-2 gap-1 rounded-md bg-background/60 p-1 sm:grid-cols-4">
          {STYLE_CATEGORIES.map(({ category, label }) => {
            const count = items.filter((item) => item.category === category).length;
            return (
              <Button key={category} type="button" role="tab" aria-selected={activeCategory === category} variant={activeCategory === category ? "primary" : "tab"} onClick={() => setActiveCategory(category)} className="h-auto min-w-0 justify-center px-2 py-2 text-[9px] uppercase tracking-[0.1em] sm:text-[10px]">
                <span className="truncate">{label}</span><span className="shrink-0 opacity-70">{count}</span>
              </Button>
            );
          })}
        </div>

        {categoryItems.length > 0 ? (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {categoryItems.map((item) => {
              const selected = item.id === selectedShirt?.id || item.id === validJacket?.id;
              return (
                <Button key={item.id} type="button" variant="quiet" onClick={() => selectItem(item)} aria-pressed={selected} className={`relative h-auto min-w-0 flex-col items-stretch overflow-hidden p-0 text-left ${selected ? "ring-2 ring-primary" : "ring-1 ring-border"}`}>
                  <img src={item.image} alt={item.name} width={768} height={1024} className="aspect-[3/4] w-full object-cover" />
                  {selected && <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-primary text-primary-foreground"><Check size={13} /></span>}
                  <span className="min-w-0 p-2.5">
                    <span className="block truncate text-[11px] font-medium text-foreground">{item.name}</span>
                    <span className="mt-1 block truncate text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{item.colour}</span>
                  </span>
                </Button>
              );
            })}
          </div>
        ) : <p className="mt-4 py-8 text-center text-xs text-muted-foreground">No pieces in this collection yet.</p>}

        <div className="mt-5 border-t border-border pt-4">
          {selectedShirt ? (
            <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex shrink-0 gap-1.5">
                  {selectedPieces.map((item) => <img key={item.id} src={item.image} alt={item.name} className="aspect-[3/4] w-14 rounded-sm object-cover ring-1 ring-border" />)}
                </div>
                <div className="min-w-0">
                  <p className="font-mono text-[8px] uppercase tracking-[0.18em] text-accent">Selected look</p>
                  <p className="mt-1 truncate font-display text-base">{selectedPieces.map((item) => item.name).join(" + ")}</p>
                  <p className="mt-1 text-[10px] text-muted-foreground">Choose a matching jacket, or try the shirt on by itself.</p>
                </div>
              </div>
              <Button asChild className="w-full sm:w-auto">
                <Link to="/try-on" search={{ look: selectedPieces.map((item) => item.id).join("~") }}>Try selected look</Link>
              </Button>
            </div>
          ) : <p className="text-center text-[11px] text-muted-foreground">Select any shirt to start. Choosing a jacket will add a matching shirt automatically.</p>}
        </div>
      </section>

      {outfits ? (
        <section className="mt-6 animate-rise grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {outfits.map((look, index) => {
            const pieces = look.itemIds.map((id) => byId.get(id)).filter((item) => item !== undefined);
            return (
              <article key={index} className="rounded-md bg-card/80 p-4 ring-1 ring-border">
                <div className="grid grid-cols-[auto_minmax(0,1fr)] gap-3">
                  <div className="flex shrink-0 gap-1.5">
                    {pieces.map((item) => (
                      <img key={item.id} src={item.image} alt={item.name} loading="lazy" width={768} height={1024} className="aspect-[3/4] w-16 rounded-sm object-cover ring-1 ring-border" />
                    ))}
                  </div>
                  <div className="min-w-0">
                    <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-accent">Look 0{index + 1}</p>
                    <h2 className="mt-1 font-display text-[17px]">{look.title}</h2>
                    <p className="mt-1 text-[11px] leading-snug text-muted-foreground">{look.reason}</p>
                  </div>
                </div>
                <Link to="/try-on" search={{ look: look.itemIds.join("~") }} className="mt-4 block border-t border-border pt-3 text-right text-[10px] uppercase tracking-[0.18em] text-accent">Try this look →</Link>
              </article>
            );
          })}
        </section>
      ) : (
        <div className="mt-12 border-t border-border pt-4 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{!loading && !hasShirt ? "Add at least one shirt to begin" : styling ? "Reading every piece" : "Your three looks will appear here"}</div>
      )}
    </AppShell>
  );
}
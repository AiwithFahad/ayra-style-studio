import { createFileRoute, Link } from "@tanstack/react-router";
import { Camera, CameraOff, Download, ImageUp, Loader2, RotateCcw, Sparkles, Video } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { useWardrobe } from "@/hooks/use-wardrobe";
import { supabase } from "@/integrations/supabase/client";
import { captureVideoFrame, extractBestFrame, normaliseImage } from "@/lib/frame-capture";
import { streamImage } from "@/lib/stream-image";
import type { StylistOutfit } from "@/lib/stylist.functions";
import type { WardrobeItem } from "@/lib/wardrobe-data";

export const Route = createFileRoute("/_authenticated/try-on")({
  validateSearch: (search) => z.object({ look: z.string().optional() }).parse(search),
  head: () => ({ meta: [
    { title: "Virtual Try-on — AYRA" },
    { name: "description", content: "See an AYRA outfit on a photo, video frame or live camera shot." },
    { property: "og:title", content: "Virtual Try-on — AYRA" },
    { property: "og:description", content: "Try your stylist's looks on before getting dressed." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: TryOnPage,
});

type Mode = "camera" | "photo" | "video";
type Look = { key: string; title: string; reason: string; pieces: WardrobeItem[] };

const MODES: { id: Mode; label: string; icon: typeof Camera }[] = [
  { id: "camera", label: "Live camera", icon: Camera },
  { id: "photo", label: "Upload photo", icon: ImageUp },
  { id: "video", label: "Short video", icon: Video },
];

function TryOnPage() {
  const { look } = Route.useSearch();
  const { items, loading } = useWardrobe();
  const [saved, setSaved] = useState<StylistOutfit[]>([]);
  useEffect(() => {
    try {
      setSaved(JSON.parse(localStorage.getItem("ayra:outfits") ?? "[]"));
    } catch {
      setSaved([]);
    }
  }, []);

  const looks = useMemo<Look[]>(() => {
    const byId = new Map(items.map((i) => [i.id, i]));
    return saved
      .map((o) => ({ key: o.itemIds.join("~"), title: o.title, reason: o.reason, pieces: o.itemIds.map((id) => byId.get(id)).filter((i) => i !== undefined) }))
      .filter((l) => l.pieces.length > 0);
  }, [saved, items]);

  const linkedLook = useMemo<Look | undefined>(() => {
    if (!look) return undefined;
    const requested = look.split("~").map((id) => items.find((item) => item.id === id)).filter((item) => item !== undefined);
    const shirt = requested.find((item) => item.category.endsWith("shirt"));
    if (!shirt) return undefined;
    const group = shirt.category.split(" ")[0];
    const jacket = requested.find((item) => item.category === `${group} jacket`);
    const pieces = jacket ? [shirt, jacket] : [shirt];
    return {
      key: look,
      title: jacket ? `${shirt.colour} + ${jacket.colour}` : shirt.name,
      reason: jacket ? `${shirt.name} paired with ${jacket.name}.` : `${shirt.name} worn on its own.`,
      pieces,
    };
  }, [items, look]);

  const shirts = useMemo(() => items.filter((item) => item.category.endsWith("shirt")), [items]);
  const [selectedShirtId, setSelectedShirtId] = useState<string | null>(null);
  const [selectedJacketId, setSelectedJacketId] = useState<string | null>(null);
  const appliedLinkedLook = useRef<string | null>(null);
  const selectedShirt = shirts.find((item) => item.id === selectedShirtId) ?? shirts[0];
  const compatibleJackets = useMemo(() => items.filter((item) => selectedShirt && item.category === `${selectedShirt.category.split(" ")[0]} jacket`), [items, selectedShirt]);
  const selectedJacket = compatibleJackets.find((item) => item.id === selectedJacketId);
  const customLook = useMemo<Look | undefined>(() => selectedShirt ? {
    key: `custom:${selectedShirt.id}:${selectedJacket?.id ?? "none"}`,
    title: selectedJacket ? `${selectedShirt.colour} + ${selectedJacket.colour}` : selectedShirt.name,
    reason: selectedJacket ? `${selectedShirt.name} paired with ${selectedJacket.name}.` : `${selectedShirt.name} worn on its own.`,
    pieces: selectedJacket ? [selectedShirt, selectedJacket] : [selectedShirt],
  } : undefined, [selectedJacket, selectedShirt]);
  const [selectedKey, setSelectedKey] = useState<string | null>(look ?? "custom");
  useEffect(() => {
    if (!look || !linkedLook || appliedLinkedLook.current === look) return;
    const shirt = linkedLook.pieces.find((piece) => piece.category.endsWith("shirt"));
    const jacket = linkedLook.pieces.find((piece) => piece.category.endsWith("jacket"));
    if (!shirt) return;
    setSelectedShirtId(shirt.id);
    setSelectedJacketId(jacket?.id ?? null);
    setSelectedKey("custom");
    appliedLinkedLook.current = look;
  }, [linkedLook, look]);
  const selected = selectedKey === "custom"
    ? customLook
    : looks.find((candidate) => candidate.key === selectedKey) ?? (linkedLook?.key === selectedKey ? linkedLook : undefined) ?? customLook ?? looks[0];

  const [mode, setMode] = useState<Mode>("camera");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const photoInput = useRef<HTMLInputElement>(null);
  const videoInput = useRef<HTMLInputElement>(null);
  const pickerRef = useRef<HTMLElement>(null);
  const [cameraState, setCameraState] = useState<"idle" | "starting" | "live" | "denied" | "unsupported" | "notfound" | "busy">("idle");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [subject, setSubject] = useState<{ blob: Blob; url: string } | null>(null);
  const [preparing, setPreparing] = useState(false);
  const [result, setResult] = useState<{ src: string; final: boolean } | null>(null);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function stopCamera() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraState("idle");
  }
  useEffect(() => () => streamRef.current?.getTracks().forEach((t) => t.stop()), []);
  useEffect(() => {
    if (cameraState === "live" && videoRef.current && streamRef.current && videoRef.current.srcObject !== streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
    }
  }, [cameraState, mode]);

  function setSubjectBlob(blob: Blob | null) {
    setSubject((prev) => {
      if (prev) URL.revokeObjectURL(prev.url);
      return blob ? { blob, url: URL.createObjectURL(blob) } : null;
    });
    setResult(null);
  }

  function switchMode(next: Mode) {
    if (next !== "camera") stopCamera();
    setMode(next);
    setSubjectBlob(null);
    setError(null);
  }

  async function startCamera(nextFacing = facing) {
    setError(null);
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      setCameraState("unsupported");
      return;
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    setCameraState("starting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: nextFacing, width: { ideal: 1280 }, height: { ideal: 1600 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setFacing(nextFacing);
      setCameraState("live");
    } catch (err) {
      const name = err instanceof DOMException ? err.name : "";
      setCameraState(name === "NotFoundError" || name === "OverconstrainedError" ? "notfound" : name === "NotReadableError" ? "busy" : "denied");
    }
  }

  async function onPhoto(file?: File) {
    if (!file) return;
    setError(null);
    setPreparing(true);
    try {
      setSubjectBlob(await normaliseImage(file));
    } catch {
      setError("That photo couldn't be opened. Try a JPG or PNG.");
    }
    setPreparing(false);
  }

  async function onVideo(file?: File) {
    if (!file) return;
    setError(null);
    setPreparing(true);
    try {
      const { frame } = await extractBestFrame(file);
      setSubjectBlob(frame);
    } catch (err) {
      setError(err instanceof Error ? err.message : "That video couldn't be read.");
    }
    setPreparing(false);
    if (videoInput.current) videoInput.current.value = "";
  }

  async function tryOn(reuseFrame = false) {
    if (!selected) return;
    setError(null);
    let base = subject?.blob;
    if (mode === "camera" && !(reuseFrame && base)) {
      const video = videoRef.current;
      if (cameraState !== "live" || !video || !video.videoWidth) {
        setError("The camera isn't ready yet. Give it a second and try again.");
        return;
      }
      base = await captureVideoFrame(video);
      setSubjectBlob(base);
    }
    if (!base) return;
    setGenerating(true);
    setResult(null);
    try {
      const form = new FormData();
      form.append("image[]", new File([base], "subject.png", { type: "image/png" }));
      for (const piece of selected.pieces) {
        const res = await fetch(piece.image);
        const blob = await res.blob();
        form.append("image[]", new File([blob], `${piece.category.replace(" ", "-")}.${blob.type.split("/")[1] || "jpg"}`, { type: blob.type || "image/jpeg" }));
      }
      const { data } = await supabase.auth.getSession();
      await streamImage("/api/try-on", form, (src, final) => setResult({ src, final }), undefined, {
        Authorization: `Bearer ${data.session?.access_token ?? ""}`,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      setError(
        msg.includes("402") ? "AI credits are exhausted. Add credits to keep trying on looks."
        : msg.includes("429") ? "AYRA is busy right now. Please retry in a moment."
        : msg.includes("401") ? "Please sign in again."
        : "The try-on couldn't be created. Please retry.",
      );
      setResult(null);
    }
    setGenerating(false);
  }

  function tryAnother() {
    setResult(null);
    setError(null);
    if (mode === "camera") setSubjectBlob(null);
    pickerRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function saveResult() {
    if (!result) return;
    const a = document.createElement("a");
    a.href = result.src;
    a.download = `ayra-try-on-${Date.now()}.png`;
    a.click();
  }

  const shell = { eyebrow: "Fitting room · virtual try-on", title: "Try it in your world" };
  if (loading) return <AppShell {...shell} note="Opening wardrobe"><p className="py-12 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Preparing your looks</p></AppShell>;
  if (!selected) return (
    <AppShell {...shell} note="No looks yet">
      <div className="rounded-md bg-card/80 p-6 text-center ring-1 ring-border">
        <p className="text-sm text-muted-foreground">Add a shirt to your wardrobe before opening the fitting room.</p>
        <Link to="/" className="mt-4 inline-block text-[10px] uppercase tracking-[0.18em] text-accent">Go to the wardrobe →</Link>
      </div>
    </AppShell>
  );

  const canTry = !generating && !preparing && (!!subject || (mode === "camera" && cameraState === "live"));

  return (
    <AppShell {...shell} note={selected.title}>
      <section ref={pickerRef} className="mb-6 scroll-mt-4 rounded-md bg-card/70 p-4 ring-1 ring-border sm:p-5">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
          <div className="min-w-0">
            <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-accent">Build a look</p>
            <h2 className="mt-1 font-display text-lg">Choose any wardrobe piece</h2>
          </div>
          <span className="shrink-0 text-[10px] text-muted-foreground">{shirts.length} shirts</span>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="min-w-0 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Shirt
            <select value={selectedShirt?.id ?? ""} onChange={(event) => { setSelectedShirtId(event.target.value); setSelectedJacketId(null); setSelectedKey("custom"); setResult(null); }} className="mt-1.5 h-11 w-full truncate rounded-md border border-input bg-background px-3 text-sm normal-case text-foreground outline-none focus:ring-1 focus:ring-ring">
              {shirts.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.colour}</option>)}
            </select>
          </label>
          <label className="min-w-0 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Jacket
            <select value={selectedJacket?.id ?? ""} onChange={(event) => { setSelectedJacketId(event.target.value || null); setSelectedKey("custom"); setResult(null); }} className="mt-1.5 h-11 w-full truncate rounded-md border border-input bg-background px-3 text-sm normal-case text-foreground outline-none focus:ring-1 focus:ring-ring">
              <option value="">No jacket</option>
              {compatibleJackets.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.colour}</option>)}
            </select>
          </label>
        </div>
        {customLook && <div className="mt-4 flex gap-2">{customLook.pieces.map((piece) => <img key={piece.id} src={piece.image} alt={piece.name} loading="lazy" width={768} height={1024} className="aspect-[3/4] w-16 rounded-sm object-cover ring-1 ring-border" />)}</div>}
      </section>

      {looks.length > 0 && <>
      <p className="mb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">Stylist suggestions</p>
      <div className="-mx-1 mb-5 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none]">
        {looks.map((l, i) => (
          <Button key={l.key} variant="quiet" type="button" onClick={() => { setSelectedKey(l.key); setResult(null); }} className={`h-auto shrink-0 flex-col items-start p-2 text-left ${l.key === selected.key ? "ring-primary" : "ring-border"}`}>
            <div className="flex gap-1">{l.pieces.map((p) => <img key={p.id} src={p.image} alt={p.name} className="aspect-[3/4] w-10 rounded-sm object-cover" />)}</div>
            <p className="mt-1.5 font-mono text-[8px] uppercase tracking-[0.18em] text-accent">Look 0{i + 1}</p>
            <p className="max-w-28 truncate font-display text-[13px]">{l.title}</p>
          </Button>
        ))}
      </div>
      </>}

      <div role="tablist" className="mb-4 grid grid-cols-3 gap-1 rounded-md bg-card/70 p-1 ring-1 ring-border">
        {MODES.map((m) => (
          <Button key={m.id} variant={mode === m.id ? "primary" : "tab"} role="tab" aria-selected={mode === m.id} type="button" onClick={() => switchMode(m.id)} className="h-auto min-w-0 flex-col gap-1 rounded-sm px-1 py-2 text-[9px] uppercase tracking-[0.12em] sm:text-[10px]">
            <m.icon size={15} strokeWidth={1.6} />{m.label}
          </Button>
        ))}
      </div>

      <section className="overflow-hidden rounded-md bg-card/80 ring-1 ring-border">
        <div className="grid gap-px bg-border sm:grid-cols-2">
          <div className="relative aspect-[3/4] overflow-hidden bg-secondary">
            <p className="absolute left-2 top-2 z-10 flex items-center gap-1.5 rounded-sm bg-card/80 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-[0.16em]">
              {mode === "camera" && cameraState === "live" && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive" />}
              {mode === "camera" && cameraState === "live" ? "Live" : "Input"}
            </p>
            {mode === "camera" && <video ref={videoRef} autoPlay muted playsInline className={cameraState === "live" ? `h-full w-full object-cover ${facing === "user" ? "-scale-x-100" : ""}` : "hidden"} />}
            {mode === "camera" && cameraState === "live" && (
              <>
                <div className="pointer-events-none absolute inset-6 rounded-[40%_40%_12%_12%] border border-dashed border-primary-foreground/40" />
                <Button type="button" variant="quiet" aria-label="Switch camera" onClick={() => startCamera(facing === "user" ? "environment" : "user")} className="absolute right-2 top-2 z-10 h-8 w-8 rounded-full p-0"><RotateCcw size={14} /></Button>
                {subject && (
                  <figure className="absolute bottom-2 right-2 z-10 w-16 overflow-hidden rounded-sm ring-2 ring-card sm:w-20">
                    <img src={subject.url} alt="Captured frame" className="aspect-[3/4] w-full object-cover" />
                    <figcaption className="bg-card/90 py-0.5 text-center font-mono text-[7px] uppercase tracking-[0.14em]">Captured</figcaption>
                  </figure>
                )}
              </>
            )}
            {mode !== "camera" && subject ? (
              <img src={subject.url} alt="Selected subject" className="h-full w-full object-cover" />
            ) : mode === "camera" && cameraState === "live" ? null : (
              <div className="grid h-full place-items-center px-4 text-center text-muted-foreground">
                {preparing ? <div><Loader2 className="mx-auto mb-2 animate-spin" size={22} /><p className="text-[10px] uppercase tracking-[0.16em]">{mode === "video" ? "Finding the best frame" : "Preparing photo"}</p></div>
                : mode === "camera" ? (
                  <div className="max-w-60">
                    {cameraState === "starting" ? <Loader2 className="mx-auto mb-2 animate-spin" size={22} />
                    : cameraState === "idle" ? <Camera className="mx-auto mb-2" size={22} />
                    : <CameraOff className="mx-auto mb-2" size={22} />}
                    {cameraState === "denied" ? (
                      <div className="space-y-2 text-left text-[11px] leading-snug">
                        <p className="text-center font-display text-sm text-foreground">Camera access is off</p>
                        <ol className="list-decimal space-y-1 pl-4">
                          <li>Tap the lock or camera icon next to the address bar.</li>
                          <li>Set Camera to “Allow”.</li>
                          <li>Come back and tap “Try the camera again”.</li>
                        </ol>
                        <p className="text-center">Or switch to Upload photo.</p>
                      </div>
                    ) : (
                      <p className="text-[11px] leading-snug">
                        {cameraState === "starting" ? "Waiting for camera permission…"
                        : cameraState === "unsupported" ? "This browser can't open the camera (it needs a secure https page). Try uploading a photo instead."
                        : cameraState === "notfound" ? "No camera was found on this device. Try uploading a photo instead."
                        : cameraState === "busy" ? "Your camera is being used by another app. Close it and try again."
                        : "Open the camera, stand back so your upper body fits the frame, then tap Try it on."}
                      </p>
                    )}
                  </div>
                ) : (
                  <Button variant="ghost" type="button" onClick={() => (mode === "photo" ? photoInput : videoInput).current?.click()} className="h-auto max-w-48 flex-col items-center gap-2 whitespace-normal text-muted-foreground">
                    {mode === "photo" ? <ImageUp size={22} /> : <Video size={22} />}
                    <span className="text-[11px] leading-snug">{mode === "photo" ? "Choose a photo from your gallery" : "Record or choose a 5–10 second video"}</span>
                  </Button>
                )}
              </div>
            )}
          </div>
          <div className="relative aspect-[3/4] overflow-hidden bg-secondary">
            <p className="absolute left-2 top-2 z-10 rounded-sm bg-card/80 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-[0.16em]">Result</p>
            {result ? (
              <img src={result.src} alt={`Wearing ${selected.title}`} className={`h-full w-full object-cover transition-[filter] duration-500 ${result.final ? "blur-0" : "blur-2xl"}`} />
            ) : generating ? (
              <div className="relative h-full">
                {subject && <img src={subject.url} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40 blur-md" />}
                <div className="relative grid h-full place-items-center text-center"><div className="rounded-md bg-card/85 px-4 py-3 ring-1 ring-border"><Loader2 className="mx-auto mb-2 animate-spin" size={22} /><p className="text-[10px] uppercase tracking-[0.16em]">Dressing the look</p><p className="mt-1 text-[10px] text-muted-foreground">Usually 20–60 seconds</p></div></div>
              </div>
            ) : (
              <div className="grid h-full grid-rows-2 gap-px">
                {selected.pieces.map((p) => <img key={p.id} src={p.image} alt={p.name} className="h-full min-h-0 w-full object-cover opacity-80" />)}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2 p-4">
          {selected.reason && <p className="text-[11px] leading-snug text-muted-foreground">{selected.reason}</p>}
          {error && <p role="alert" className="text-xs text-destructive">{error}</p>}
          {mode === "camera" && cameraState !== "live" ? (
            <Button onClick={() => startCamera()} disabled={cameraState === "starting"} className="w-full"><Camera size={16} /> {cameraState === "idle" || cameraState === "starting" ? "Open camera" : "Try the camera again"}</Button>
          ) : (
            <Button onClick={() => tryOn()} disabled={!canTry} className="w-full">
              {generating ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />} {generating ? "Generating" : "Try it on"}
            </Button>
          )}
          {result?.final && (
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <Button variant="outline" onClick={saveResult}><Download size={15} /> Save</Button>
              <Button variant="outline" onClick={() => tryOn(true)} disabled={generating}><RotateCcw size={15} /> Retry</Button>
              <Button variant="outline" onClick={tryAnother}><Sparkles size={15} /> Try another outfit</Button>
            </div>
          )}
          {mode !== "camera" && subject && !generating && (
            <Button variant="quiet" className="w-full" onClick={() => { setSubjectBlob(null); setError(null); }}>
              {mode === "photo" ? "Choose another photo" : "Choose another video"}
            </Button>
          )}
          <p className="pt-1 text-center text-[9px] uppercase tracking-[0.14em] text-muted-foreground">Photos are only sent to create your try-on</p>
        </div>
      </section>

      <input ref={photoInput} type="file" accept="image/*" className="sr-only" onChange={(e) => onPhoto(e.target.files?.[0])} />
      <input ref={videoInput} type="file" accept="video/*" capture="environment" className="sr-only" onChange={(e) => onVideo(e.target.files?.[0])} />
    </AppShell>
  );
}

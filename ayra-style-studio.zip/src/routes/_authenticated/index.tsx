import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ArrowDown, ArrowRight, Check, Heart, ImagePlus, Instagram, Loader2, Mail, MapPin, Quote, Search, ShieldCheck, ShoppingBag, Sparkles, Trash2, Truck, Undo2 } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { ProductCarousel } from "@/components/product-carousel";
import { Button } from "@/components/ui/button";
import { useWardrobe } from "@/hooks/use-wardrobe";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/lib/product-display";
import { analyzeAndSaveItem } from "@/lib/wardrobe.functions";

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({ meta: [
    { title: "AYRA — The Intelligent Wardrobe" },
    { name: "description", content: "Discover your private AYRA wardrobe, curated collections, AI styling, and virtual try-on." },
    { property: "og:title", content: "AYRA — The Intelligent Wardrobe" },
    { property: "og:description", content: "A modern fashion wardrobe shaped around the pieces you own." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: WardrobePage,
});

const testimonials = [
  { quote: "AYRA makes the clothes I already own feel new again. Every suggestion is genuinely wearable.", name: "Maya R.", detail: "Wardrobe member" },
  { quote: "The camera try-on turns a morning decision into a calm, considered moment.", name: "Noor A.", detail: "Early access member" },
  { quote: "I can organise pieces for the whole family without losing the pleasure of browsing them.", name: "Sam K.", detail: "Wardrobe member" },
];

const articles = [
  { eyebrow: "The wardrobe journal", title: "How to build more looks from fewer pieces", copy: "A practical guide to colour, proportion, and finding fresh combinations in clothes you already own." },
  { eyebrow: "Inside AYRA", title: "Why private wardrobes make styling personal", copy: "The best suggestions begin with your real clothes, your real colours, and the way you actually dress." },
];

function ProductCard({ item, compact = false }: { item: ReturnType<typeof useWardrobe>["items"][number]; compact?: boolean }) {
  return <Link to="/product/$id" params={{ id: item.id }} className="group block min-w-0">
    <article>
      <div className="overflow-hidden bg-card ring-1 ring-border"><img src={item.image} alt={item.name} loading="lazy" width={768} height={1024} className={`${compact ? "aspect-[4/5]" : "aspect-[3/4]"} w-full object-cover transition-transform duration-500 group-hover:scale-[1.025] motion-reduce:transform-none`} /></div>
      <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-2 pt-3">
        <div className="min-w-0"><h3 className="truncate text-xs font-medium sm:text-sm">{item.name}</h3><p className="mt-1 truncate text-[9px] uppercase tracking-[0.12em] text-muted-foreground">{item.category} · {item.colour}</p></div>
        <ArrowRight size={13} className="mt-0.5 shrink-0 transition-transform group-hover:translate-x-1" />
      </div>
      <p className="mt-1 text-xs font-medium">{formatPrice(item)}</p>
    </article>
  </Link>;
}

function WardrobePage() {
  const { items, loading, error, refresh } = useWardrobe();
  const analyze = useServerFn(analyzeAndSaveItem);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [filter, setFilter] = useState<"All" | "Men" | "Kids" | "Shirts" | "Jackets">("All");
  const [editingId, setEditingId] = useState<string | null>(null);
  const filters = ["All", "Men", "Kids", "Shirts", "Jackets"] as const;
  const visibleItems = useMemo(() => items.filter((item) => {
    if (filter === "All") return true;
    if (filter === "Men") return item.category.startsWith("Men");
    if (filter === "Kids") return item.category.startsWith("Kid");
    if (filter === "Shirts") return item.category.endsWith("shirt");
    return item.category.endsWith("jacket");
  }), [filter, items]);
  const shirts = useMemo(() => items.filter((item) => item.category.endsWith("shirt")), [items]);
  const jackets = useMemo(() => items.filter((item) => item.category.endsWith("jacket")), [items]);
  const latest = items.slice(0, 8);
  const heroItem = items[0];

  function countFor(value: typeof filters[number]) {
    if (value === "All") return items.length;
    if (value === "Men") return items.filter((item) => item.category.startsWith("Men")).length;
    if (value === "Kids") return items.filter((item) => item.category.startsWith("Kid")).length;
    if (value === "Shirts") return shirts.length;
    return jackets.length;
  }

  async function updateCategory(id: string, category: "Men shirt" | "Men jacket" | "Kid shirt" | "Kid jacket") {
    setEditingId(id); setFormError(null);
    const { error: updateError } = await supabase.from("wardrobe_items").update({ category }).eq("id", id);
    if (updateError) setFormError(updateError.message);
    await refresh(); setEditingId(null);
  }

  async function removeItem(id: string, storagePath: string) {
    if (!window.confirm("Remove this piece from your wardrobe?")) return;
    setEditingId(id); setFormError(null);
    const { error: deleteError } = await supabase.from("wardrobe_items").delete().eq("id", id);
    if (deleteError) setFormError(deleteError.message);
    else { await supabase.storage.from("wardrobe").remove([storagePath]); await refresh(); }
    setEditingId(null);
  }

  async function choosePhoto(file?: File) {
    if (!file) return;
    setSaving(true); setFormError(null);
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    if (!user) { setFormError("Please sign in again."); setSaving(false); return; }
    const extension = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${user.id}/${crypto.randomUUID()}.${extension}`;
    const { error: uploadError } = await supabase.storage.from("wardrobe").upload(path, file, { contentType: file.type });
    if (uploadError) { setFormError(uploadError.message); setSaving(false); return; }
    try { await analyze({ data: { path, name: file.name.replace(/\.[^.]+$/, "") || "New piece" } }); }
    catch (err) { await supabase.storage.from("wardrobe").remove([path]); setFormError(err instanceof Error ? err.message : "Could not add this piece."); }
    if (inputRef.current) inputRef.current.value = "";
    await refresh(); setSaving(false);
  }

  return <AppShell storefront eyebrow="The wardrobe · contact sheet" title="The wardrobe, catalogued" note={`${items.length} pieces · 4 categories`}>
    <section className="relative -mx-4 min-h-[31rem] overflow-hidden bg-primary sm:-mx-6 sm:min-h-[36rem] lg:-mx-10 lg:min-h-[40rem]" aria-labelledby="hero-title">
      {heroItem ? <img src={heroItem.image} alt="" className="absolute inset-0 h-full w-full object-cover object-center opacity-80" /> : <div className="absolute inset-0 bg-secondary" />}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/85 via-primary/45 to-transparent" />
      <div className="relative flex min-h-[31rem] max-w-2xl flex-col justify-center px-6 text-primary-foreground sm:min-h-[36rem] sm:px-10 lg:min-h-[40rem] lg:px-14">
        <p className="font-mono text-[9px] uppercase tracking-[0.26em] text-primary-foreground/70">Private collection · Atelier No. 01</p>
        <h1 id="hero-title" className="mt-5 font-display text-5xl leading-[0.96] sm:text-7xl lg:text-8xl">Your wardrobe, intelligently styled.</h1>
        <p className="mt-5 max-w-md text-sm leading-6 text-primary-foreground/80 sm:text-base">Catalogue what you own, discover considered combinations, and see every look on you before you wear it.</p>
        <div className="mt-7 flex flex-wrap gap-3"><Button asChild size="lg" variant="secondary"><Link to="/stylist">Style me <Sparkles size={15} /></Link></Button><Button asChild size="lg" variant="outline" className="border-primary-foreground/50 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground hover:text-primary"><a href="#wardrobe">Shop wardrobe <ArrowDown size={15} /></a></Button></div>
      </div>
      {heroItem && <Link to="/product/$id" params={{ id: heroItem.id }} className="absolute bottom-5 right-5 hidden w-40 bg-card/95 p-2 text-foreground shadow-editorial sm:block"><div className="grid grid-cols-[3.5rem_1fr] gap-2"><img src={heroItem.image} alt="" className="aspect-square w-14 object-cover" /><div className="min-w-0 self-center"><p className="truncate text-[10px] font-medium">{heroItem.name}</p><p className="mt-1 text-[9px] text-muted-foreground">View the latest →</p></div></div></Link>}
    </section>

    {!loading && <ProductCarousel eyebrow="Featured edit · Shirts" title="The shirt selection" items={shirts} />}

    <section id="wardrobe" className="scroll-mt-6 border-t border-border py-12 sm:py-16" aria-labelledby="wardrobe-title">
      <div className="mb-7 grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end"><div className="min-w-0"><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">AYRA · Atelier No. 01</p><h2 id="wardrobe-title" className="mt-2 text-2xl font-semibold sm:text-3xl">Shop by category</h2><p className="mt-2 font-display text-xl">The wardrobe, catalogued</p></div><p className="text-xs text-muted-foreground">{items.length} pieces · 4 categories</p></div>
      <div className="mb-6 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]" aria-label="Filter wardrobe">{filters.map((value) => <Button key={value} size="sm" variant={filter === value ? "primary" : "quiet"} aria-pressed={filter === value} onClick={() => setFilter(value)} className="shrink-0 rounded-full px-3 text-[11px]">{value} <span className="opacity-60">{countFor(value)}</span></Button>)}</div>
      {error && <p role="alert" className="mb-4 text-xs text-destructive">{error}</p>}
      {loading ? <p className="py-12 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Opening your wardrobe</p> : <div className="animate-rise grid grid-cols-2 gap-x-3 gap-y-7 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        {visibleItems.map((item) => <article key={item.id} className="group min-w-0"><div className="relative overflow-hidden bg-card ring-1 ring-border"><Link to="/product/$id" params={{ id: item.id }} aria-label={`View ${item.name}`}><img src={item.image} alt={item.name} loading="lazy" width={768} height={1024} className="aspect-[3/4] w-full object-cover transition-transform duration-500 group-hover:scale-[1.025] motion-reduce:transform-none" /></Link><Button variant="quiet" size="icon" disabled={editingId === item.id} onClick={() => removeItem(item.id, item.storagePath)} aria-label={`Remove ${item.name}`} title="Remove piece" className="absolute right-2 top-2 size-9 min-h-9 bg-card/90"><Trash2 size={14} /></Button></div><div className="pt-3"><Link to="/product/$id" params={{ id: item.id }} className="story-link"><h3 className="truncate text-[13px] font-medium">{item.name}</h3></Link><p className="mt-1 text-xs font-medium">{formatPrice(item)}</p><div className="mt-2 flex flex-wrap gap-1"><select aria-label={`Category for ${item.name}`} value={item.category} disabled={editingId === item.id} onChange={(event) => updateCategory(item.id, event.target.value as typeof item.category)} className="min-w-0 rounded-sm border-0 bg-secondary px-1.5 py-1 text-[9px] uppercase text-muted-foreground outline-none ring-ring focus:ring-1"><option>Men shirt</option><option>Men jacket</option><option>Kid shirt</option><option>Kid jacket</option></select><span className="rounded-sm bg-secondary px-1.5 py-0.5 text-[9px] uppercase text-muted-foreground">{item.colour}</span></div></div></article>)}
        {visibleItems.length === 0 && <div className="col-span-full border border-dashed border-border py-12 text-center text-xs text-muted-foreground">No pieces match this filter.</div>}
        <Button variant="quiet" disabled={saving} onClick={() => inputRef.current?.click()} className="aspect-[3/4] h-auto flex-col border border-dashed border-accent/50 bg-card/55 text-muted-foreground ring-0">{saving ? <Loader2 size={22} strokeWidth={1.4} className="animate-spin" /> : <ImagePlus size={22} strokeWidth={1.4} />}<span className="text-[10px] uppercase tracking-[0.18em]">{saving ? "Reading the piece" : "Add a piece"}</span></Button>
      </div>}
      {formError && <p role="alert" className="mt-4 text-xs text-destructive">{formError}</p>}<input ref={inputRef} type="file" accept="image/*" className="sr-only" onChange={(event) => choosePhoto(event.target.files?.[0])} />
    </section>

    <section className="grid border-t border-border py-14 sm:py-20 lg:grid-cols-[.9fr_1.1fr]" aria-labelledby="about-title"><div className="grid grid-cols-2 gap-3 bg-secondary p-4 sm:p-6"><img src={shirts[0]?.image} alt="A shirt from the AYRA wardrobe" className="aspect-[3/4] w-full object-cover" /><img src={jackets[0]?.image} alt="A jacket from the AYRA wardrobe" className="mt-10 aspect-[3/4] w-full object-cover" /></div><div className="flex flex-col justify-center px-0 pt-8 lg:px-14 lg:pt-0"><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">About AYRA</p><h2 id="about-title" className="mt-3 font-display text-4xl leading-tight sm:text-6xl">A clearer way to see what you already own.</h2><p className="mt-6 max-w-xl text-sm leading-7 text-muted-foreground">AYRA turns the private wardrobe into a living edit. Every shirt and jacket remains yours, while intelligent styling helps reveal useful combinations with colour, formality, and real life in mind.</p><Button asChild variant="link" className="mt-5 w-fit px-0"><Link to="/stylist">Meet your AI stylist <ArrowRight size={15} /></Link></Button></div></section>

    <section id="latest-drop" className="border-t border-border py-14 sm:py-20" aria-labelledby="latest-title"><div className="mb-7 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4"><div><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">Just catalogued</p><h2 id="latest-title" className="mt-2 text-2xl font-semibold sm:text-3xl">The latest drop</h2></div><Button asChild variant="link" className="px-0"><a href="#product-showcase">Explore all <ArrowRight size={14} /></a></Button></div><div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">{latest.map((item) => <ProductCard key={item.id} item={item} />)}</div></section>

    <section className="border-t border-border py-14 sm:py-20" aria-labelledby="collections-title"><div className="mb-7"><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">Curated edits</p><h2 id="collections-title" className="mt-2 text-2xl font-semibold sm:text-3xl">Featured collections</h2></div><div className="grid gap-4 lg:grid-cols-2">{[{ title: "The shirt study", copy: `${shirts.length} pieces for considered everyday dressing`, image: shirts[1], href: "/stylist" as const }, { title: "The outer layer", copy: `${jackets.length} jackets made to complete the look`, image: jackets[1], href: "/try-on" as const }].map((collection) => collection.image && <Link key={collection.title} to={collection.href} className="group relative min-h-80 overflow-hidden bg-primary"><img src={collection.image.image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-75 transition-transform duration-700 group-hover:scale-[1.03] motion-reduce:transform-none" /><div className="absolute inset-0 bg-gradient-to-t from-primary/85 via-transparent to-transparent" /><div className="absolute inset-x-0 bottom-0 p-6 text-primary-foreground"><p className="font-display text-3xl">{collection.title}</p><p className="mt-2 text-xs text-primary-foreground/75">{collection.copy}</p><span className="mt-4 inline-flex items-center gap-2 text-xs font-medium">Explore collection <ArrowRight size={13} /></span></div></Link>)}</div></section>

    <section id="product-showcase" className="border-t border-border py-14 sm:py-20" aria-labelledby="showcase-title"><div className="mb-7 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end"><div><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">Your complete edit</p><h2 id="showcase-title" className="mt-2 text-2xl font-semibold sm:text-3xl">Product showcase</h2></div><p className="text-xs text-muted-foreground">Every piece opens its own detail and try-on page.</p></div><div className="grid grid-cols-2 gap-x-3 gap-y-8 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">{items.map((item) => <ProductCard key={item.id} item={item} compact />)}</div></section>

    <section className="border-t border-border py-14 sm:py-20" aria-labelledby="reviews-title"><div className="mb-7"><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">The AYRA community</p><h2 id="reviews-title" className="mt-2 text-2xl font-semibold sm:text-3xl">Customer reviews</h2></div><div className="flex snap-x gap-3 overflow-x-auto pb-4 [scrollbar-width:none] lg:grid lg:grid-cols-3 lg:overflow-visible">{testimonials.map((item) => <figure key={item.name} className="min-w-[86%] snap-center border border-border bg-card p-6 sm:min-w-[48%] lg:min-w-0"><Quote size={18} className="text-accent" /><blockquote className="mt-8 font-display text-2xl leading-snug">“{item.quote}”</blockquote><figcaption className="mt-10 border-t border-border pt-4 text-xs"><span className="font-medium">{item.name}</span><span className="ml-2 text-muted-foreground">{item.detail}</span></figcaption></figure>)}</div><div className="mt-8 grid grid-cols-2 border-y border-border py-5 text-[9px] uppercase tracking-[0.12em] text-muted-foreground sm:grid-cols-4">{[[Truck,"Easy access"],[ShieldCheck,"Private wardrobe"],[Undo2,"Retry any look"],[Sparkles,"AI styling"]].map(([Icon,label]) => { const C = Icon as typeof Truck; return <div key={String(label)} className="flex items-center justify-center gap-2 py-2"><C size={15} /><span>{String(label)}</span></div>; })}</div></section>

    <section className="border-t border-border py-14 sm:py-20" aria-labelledby="news-title"><div className="mb-7"><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">Notes on personal style</p><h2 id="news-title" className="mt-2 text-2xl font-semibold sm:text-3xl">Latest news & articles</h2></div><div className="grid gap-4 md:grid-cols-2">{articles.map((article, index) => <article key={article.title} className="grid overflow-hidden bg-card ring-1 ring-border sm:grid-cols-[.9fr_1.1fr]"><img src={(index ? jackets[2] : shirts[2])?.image} alt="" className="aspect-[4/3] h-full w-full object-cover" /><div className="flex flex-col justify-center p-6"><p className="font-mono text-[8px] uppercase tracking-[0.18em] text-accent">{article.eyebrow}</p><h3 className="mt-3 font-display text-2xl leading-tight">{article.title}</h3><p className="mt-4 text-xs leading-6 text-muted-foreground">{article.copy}</p><Button asChild variant="link" className="mt-4 w-fit px-0"><Link to="/stylist">Read through styling <ArrowRight size={13} /></Link></Button></div></article>)}</div></section>

    <section className="border-t border-border py-14 sm:py-20" aria-labelledby="contact-title"><div className="mb-7"><p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">Contact & atelier</p><h2 id="contact-title" className="mt-2 text-2xl font-semibold sm:text-3xl">Continue the conversation</h2></div><div className="grid overflow-hidden bg-card ring-1 ring-border lg:grid-cols-[.8fr_1.2fr]"><div className="flex flex-col justify-center p-7 sm:p-10"><MapPin size={20} className="text-accent" /><h3 className="mt-6 font-display text-3xl">AYRA Digital Atelier</h3><p className="mt-4 max-w-sm text-sm leading-6 text-muted-foreground">Your wardrobe lives privately online, ready wherever you dress. Reach us for styling questions, feedback, or support.</p><Button asChild className="mt-7 w-fit"><a href="mailto:hello@ayra.style"><Mail size={15} />hello@ayra.style</a></Button></div><div className="grid grid-cols-2 gap-1 bg-secondary p-1"><img src={shirts[3]?.image} alt="AYRA shirt selection" className="h-full min-h-72 w-full object-cover" /><img src={jackets[3]?.image ?? jackets[0]?.image} alt="AYRA jacket selection" className="h-full min-h-72 w-full object-cover" /></div></div></section>

    <footer className="-mx-4 bg-card px-4 pb-8 pt-12 sm:-mx-6 sm:px-6 lg:-mx-10 lg:px-10"><div className="grid gap-10 border-b border-border pb-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.25fr]"><div><p className="font-display text-4xl">AYRA</p><p className="mt-4 max-w-xs text-xs leading-6 text-muted-foreground">A private wardrobe, intelligent styling, and virtual try-on in one considered place.</p><div className="mt-5 flex gap-2"><Button asChild variant="quiet" size="icon"><a href="mailto:hello@ayra.style" aria-label="Email AYRA"><Mail size={15} /></a></Button><Button asChild variant="quiet" size="icon"><a href="#latest-drop" aria-label="AYRA social updates"><Instagram size={15} /></a></Button></div></div><div><p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Pages</p><nav className="mt-4 grid gap-3 text-sm"><Link to="/">Wardrobe</Link><Link to="/stylist">Style Me</Link><Link to="/try-on">AI Try-On</Link><a href="#product-showcase">Products</a></nav></div><div><p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Collections</p><nav className="mt-4 grid gap-3 text-sm"><a href="#wardrobe" onClick={() => setFilter("Men")}>Men</a><a href="#wardrobe" onClick={() => setFilter("Kids")}>Kids</a><a href="#wardrobe" onClick={() => setFilter("Shirts")}>Shirts</a><a href="#wardrobe" onClick={() => setFilter("Jackets")}>Jackets</a></nav></div><div><p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Need help?</p><nav className="mt-4 grid gap-3 text-sm"><a href="mailto:hello@ayra.style">Contact us</a><a href="#contact-title">Privacy</a><a href="#contact-title">Terms & conditions</a></nav><form className="mt-5 flex" onSubmit={(event) => event.preventDefault()}><label htmlFor="ayra-email" className="sr-only">Email address</label><input id="ayra-email" type="email" placeholder="Email address" className="min-w-0 flex-1 border border-border bg-background px-3 text-xs outline-none focus:ring-1 focus:ring-ring" /><Button size="icon" aria-label="Join AYRA updates"><ArrowRight size={15} /></Button></form></div></div><div className="flex flex-col gap-2 pt-5 text-[10px] uppercase tracking-[0.12em] text-muted-foreground sm:flex-row sm:justify-between"><span>© 2026 AYRA Atelier</span><span>Your wardrobe stays private</span></div></footer>
  </AppShell>;
}

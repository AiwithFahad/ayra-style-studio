import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check, ShoppingBag, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { useWardrobe } from "@/hooks/use-wardrobe";
import { formatPrice, productGroup, productType, tryOnLookFor } from "@/lib/product-display";

export const Route = createFileRoute("/_authenticated/product/$id")({
  head: () => ({ meta: [
    { title: "Product details — AYRA" },
    { name: "description", content: "View a wardrobe piece in detail and take it into AYRA virtual try-on." },
    { property: "og:title", content: "Product details — AYRA" },
    { property: "og:description", content: "A closer look at a piece from your private AYRA wardrobe." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const { items, loading, error } = useWardrobe();
  const [bagged, setBagged] = useState(false);
  const item = items.find((candidate) => candidate.id === id);
  const suggested = useMemo(() => item ? items.filter((candidate) => candidate.id !== item.id && candidate.category.split(" ")[0] === item.category.split(" ")[0]).slice(0, 3) : [], [item, items]);
  const look = item ? tryOnLookFor(item, items) : undefined;

  if (loading) return <AppShell eyebrow="Product · Loading" title="A closer look" note="AYRA collection"><p className="py-24 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Opening this piece</p></AppShell>;
  if (error || !item) return <AppShell eyebrow="Product · Unavailable" title="Piece not found" note="AYRA collection"><div className="py-24 text-center"><p className="text-sm text-muted-foreground">This piece is no longer in your wardrobe.</p><Button asChild variant="quiet" className="mt-5"><Link to="/"><ArrowLeft size={15} />Back to wardrobe</Link></Button></div></AppShell>;

  return (
    <AppShell eyebrow={`${productGroup(item)} · ${productType(item)}`} title={item.name} note="Private collection">
      <Button asChild variant="link" className="mb-5 px-0 text-muted-foreground"><Link to="/"><ArrowLeft size={15} />Back to wardrobe</Link></Button>
      <article className="grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(22rem,.85fr)] lg:gap-14">
        <div className="overflow-hidden rounded-md bg-card ring-1 ring-border"><img src={item.image} alt={item.name} width={768} height={1024} className="aspect-[3/4] w-full object-cover" /></div>
        <div className="lg:sticky lg:top-8 lg:self-start lg:py-8">
          <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-accent">AYRA · Atelier piece</p>
          <h1 className="mt-3 font-display text-5xl leading-none sm:text-6xl">{item.name}</h1>
          <p className="mt-5 text-2xl">{formatPrice(item)}</p>
          <p className="mt-7 border-y border-border py-6 text-sm leading-7 text-muted-foreground">A {item.colour.toLowerCase()} {productType(item).toLowerCase()} from your private AYRA wardrobe, ready to style alone or build into a considered layered look.</p>
          <dl className="grid grid-cols-2 gap-y-5 py-6 text-xs"><div><dt className="uppercase tracking-[0.14em] text-muted-foreground">Category</dt><dd className="mt-1 font-medium">{item.category}</dd></div><div><dt className="uppercase tracking-[0.14em] text-muted-foreground">Colour</dt><dd className="mt-1 font-medium">{item.colour}</dd></div><div><dt className="uppercase tracking-[0.14em] text-muted-foreground">Collection</dt><dd className="mt-1 font-medium">Atelier No. 01</dd></div><div><dt className="uppercase tracking-[0.14em] text-muted-foreground">Status</dt><dd className="mt-1 font-medium">In your wardrobe</dd></div></dl>
          <div className="grid gap-3">
            <Button size="lg" onClick={() => setBagged(true)}>{bagged ? <><Check size={16} />Ready in your edit</> : <><ShoppingBag size={16} />Buy Now</>}</Button>
            {look ? <Button asChild size="lg" variant="outline"><Link to="/try-on" search={{ look }}><Sparkles size={16} />Try It On</Link></Button> : <Button size="lg" variant="outline" disabled><Sparkles size={16} />Try It On</Button>}
          </div>
          {bagged && <p role="status" className="mt-3 text-xs text-muted-foreground">This wardrobe piece is already yours and ready to style.</p>}
        </div>
      </article>

      {suggested.length > 0 && <section className="border-t border-border py-14 sm:py-20" aria-labelledby="pair-title"><div className="mb-7 flex items-end justify-between gap-4"><div><p className="font-mono text-[9px] uppercase tracking-[0.22em] text-accent">Complete the edit</p><h2 id="pair-title" className="mt-2 font-display text-4xl">Wear it with</h2></div><Button asChild variant="link" className="hidden sm:flex"><Link to="/stylist">Ask the stylist <ArrowRight size={15} /></Link></Button></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{suggested.map((piece) => <Link key={piece.id} to="/product/$id" params={{ id: piece.id }} className="group"><article className="overflow-hidden rounded-md bg-card ring-1 ring-border"><img src={piece.image} alt={piece.name} className="aspect-[3/4] w-full object-cover transition-transform duration-500 group-hover:scale-[1.025] motion-reduce:transform-none" /><div className="p-3"><h3 className="truncate text-sm font-medium">{piece.name}</h3><p className="mt-1 text-xs text-muted-foreground">{formatPrice(piece)}</p></div></article></Link>)}</div></section>}
    </AppShell>
  );
}
import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { FormEvent, useState } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (data.user) throw redirect({ to: "/" });
  },
  head: () => ({ meta: [
    { title: "Sign in — AYRA" },
    { name: "description", content: "Sign in to your private AYRA wardrobe." },
    { property: "og:title", content: "Sign in — AYRA" },
    { property: "og:description", content: "Your private personal wardrobe and stylist." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);

    if (mode === "signup") {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: window.location.origin },
      });
      if (error) setMessage(error.message);
      else if (!data.session) setMessage("Check your email to confirm your account, then sign in.");
      else await navigate({ to: "/" });
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage(error.message);
      else await navigate({ to: "/" });
    }
    setBusy(false);
  }

  return (
    <main className="grid min-h-screen place-items-center bg-background px-5 py-10 text-foreground">
      <section className="animate-rise w-full max-w-[390px]">
        <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">AYRA · Private atelier</p>
        <h1 className="mt-4 max-w-xs font-display text-4xl leading-tight">Your wardrobe, kept personal.</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">Sign in to catalogue your pieces and create looks from what you own.</p>

        <div className="mt-8 rounded-md bg-card/85 p-5 ring-1 ring-border">
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-md bg-secondary p-1">
            <Button type="button" variant={mode === "signin" ? "tab" : "quiet"} onClick={() => { setMode("signin"); setMessage(null); }}>Sign in</Button>
            <Button type="button" variant={mode === "signup" ? "tab" : "quiet"} onClick={() => { setMode("signup"); setMessage(null); }}>Create account</Button>
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" minLength={6} autoComplete={mode === "signin" ? "current-password" : "new-password"} required value={password} onChange={(event) => setPassword(event.target.value)} />
            </div>
            {message && <p role="status" className="text-xs leading-relaxed text-muted-foreground">{message}</p>}
            <Button type="submit" disabled={busy} className="w-full">
              {busy ? "Please wait" : mode === "signin" ? "Enter AYRA" : "Create my wardrobe"}
              {!busy && <ArrowRight size={15} />}
            </Button>
          </form>
        </div>
      </section>
    </main>
  );
}
// @ts-nocheck -- typed-array index math; values are always in range
const MAX_SIDE = 1024;

function canvasFrom(source: CanvasImageSource, width: number, height: number) {
  const scale = Math.min(1, MAX_SIDE / Math.max(width, height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(width * scale);
  canvas.height = Math.round(height * scale);
  canvas.getContext("2d")!.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas;
}

function toBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Could not capture the frame."))), "image/png"),
  );
}

export async function captureVideoFrame(video: HTMLVideoElement): Promise<Blob> {
  return toBlob(canvasFrom(video, video.videoWidth, video.videoHeight));
}

export async function normaliseImage(file: File): Promise<Blob> {
  const bitmap = await createImageBitmap(file);
  return toBlob(canvasFrom(bitmap, bitmap.width, bitmap.height));
}

/** Sharpness score: variance of a Laplacian on a small greyscale copy. */
function sharpness(video: HTMLVideoElement) {
  const w = 160;
  const h = Math.round((video.videoHeight / video.videoWidth) * w) || 120;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  ctx.drawImage(video, 0, 0, w, h);
  const px = ctx.getImageData(0, 0, w, h).data;
  const g = new Float32Array(w * h);
  let bright = 0;
  for (let i = 0; i < w * h; i++) {
    g[i] = 0.299 * px[i * 4] + 0.587 * px[i * 4 + 1] + 0.114 * px[i * 4 + 2];
    bright += g[i];
  }
  let sum = 0;
  let sq = 0;
  let n = 0;
  for (let y = 1; y < h - 1; y++)
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
      sum += l;
      sq += l * l;
      n++;
    }
  const mean = sum / n;
  const avg = bright / (w * h);
  const exposurePenalty = avg < 40 || avg > 220 ? 0.4 : 1;
  return (sq / n - mean * mean) * exposurePenalty;
}

function seek(video: HTMLVideoElement, t: number) {
  return new Promise<void>((resolve) => {
    video.onseeked = () => resolve();
    video.currentTime = t;
  });
}

export async function extractBestFrame(file: File): Promise<{ frame: Blob; duration: number }> {
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  const src = URL.createObjectURL(file);
  video.src = src;
  try {
    await new Promise<void>((resolve, reject) => {
      video.onloadeddata = () => resolve();
      video.onerror = () => reject(new Error("This video format can't be read. Try an MP4 or MOV."));
    });
    const duration = video.duration;
    if (!Number.isFinite(duration) || duration < 4.5 || duration > 11) {
      throw new Error("Please use a video between 5 and 10 seconds long.");
    }
    const samples = 12;
    let bestT = duration / 2;
    let bestScore = -1;
    for (let i = 0; i < samples; i++) {
      const t = (duration * (i + 0.5)) / samples;
      await seek(video, t);
      const s = sharpness(video);
      if (s > bestScore) {
        bestScore = s;
        bestT = t;
      }
    }
    await seek(video, bestT);
    return { frame: await captureVideoFrame(video), duration };
  } finally {
    URL.revokeObjectURL(src);
  }
}

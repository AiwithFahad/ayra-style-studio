export type WardrobeItem = {
  id: string;
  name: string;
  category: "Men shirt" | "Men jacket" | "Kid shirt" | "Kid jacket";
  colour: string;
  image: string;
  storagePath: string;
};

export type OutfitSuggestion = {
  id: string;
  title: string;
  items: WardrobeItem[];
  reason: string;
};

export function createOutfitSuggestions(items: WardrobeItem[]): OutfitSuggestion[] {
  if (items.length < 2) return [];
  const titles = ["Quiet tailoring", "Soft contrast", "A fresh repeat"];
  return titles.map((title, index) => {
    const first = items[index % items.length];
    const second = items[(index + 1) % items.length];
    if (!first || !second) return null;
    return {
      id: String(index + 1).padStart(2, "0"),
      title,
      items: [first, second],
      reason: `${first.colour} and ${second.colour} create a balanced pairing with an easy, considered finish.`,
    };
  }).filter((look): look is OutfitSuggestion => look !== null);
}
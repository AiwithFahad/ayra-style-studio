import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type StylistOutfit = { title: string; reason: string; itemIds: string[] };

type Row = { id: string; name: string; category: string; colour: string; image_url: string };

export const styleMe = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ outfits: StylistOutfit[] }> => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("wardrobe_items")
      .select("id, name, category, colour, image_url")
      .order("created_at", { ascending: false })
      .limit(30);
    if (error) throw new Error(error.message);
    const rows = (data ?? []) as Row[];
    if (!rows.some((r) => r.category.endsWith("shirt"))) throw new Error("Add at least one shirt so AYRA can style you.");

    const images = await Promise.all(
      rows.map(async (r) => {
        const { data: blob } = await supabase.storage.from("wardrobe").download(r.image_url);
        return blob ? { bytes: new Uint8Array(await blob.arrayBuffer()), mediaType: blob.type || "image/jpeg" } : null;
      }),
    );

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI is not configured.");
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText } = await import("ai");
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });

    const content: Array<{ type: "text"; text: string } | { type: "file"; data: Uint8Array; mediaType: string }> = [
      {
        type: "text",
        text: `You are AYRA, an editorial personal stylist. Below are the user's wardrobe items, each labelled with its id, category and colour, followed by its photo.

Suggest exactly 3 distinct outfits. Rules:
- Use ONLY the item ids listed. Never invent items.
- Every outfit has exactly one shirt, plus an optional jacket.
- Men shirt pairs only with Men jacket; Kid shirt pairs only with Kid jacket. Never mix men and kid pieces.
- Judge colour harmony and how formal each piece looks in its photo; pair pieces of similar formality.
- If there are fewer good combinations, you may repeat a shirt with a different (or no) jacket.
- reason: one or two short sentences naming the actual colours and items and why they work.
- title: 2-4 evocative words.

Reply with only JSON: {"outfits":[{"title":"...","shirt_id":"...","jacket_id":"... or null","reason":"..."}]}`,
      },
    ];
    rows.forEach((r, i) => {
      content.push({ type: "text", text: `Item id=${r.id} | ${r.category} | colour: ${r.colour} | name: ${r.name}` });
      const img = images[i];
      if (img) content.push({ type: "file", data: img.bytes, mediaType: img.mediaType });
    });

    let text: string;
    try {
      const result = streamText({
        model: provider.responses("openai/gpt-6-astra"),
        messages: [{ role: "user", content }],
        providerOptions: {
          openai: {
            store: false,
            forceReasoning: true,
            reasoningEffort: "medium",
            reasoningSummary: "auto",
            include: ["reasoning.encrypted_content"],
          },
        },
      });
      text = await result.text;
    } catch (err) {
      console.error("Stylist AI failed", err);
      const status = (err as { statusCode?: number })?.statusCode;
      if (status === 402) throw new Error("AI credits are exhausted. Add credits to keep styling.");
      if (status === 429) throw new Error("AYRA is busy right now. Please try again in a moment.");
      throw new Error("AYRA couldn't put looks together just now. Please try again.");
    }

    const byId = new Map(rows.map((r) => [r.id, r]));
    let parsed: { outfits?: Array<{ title?: string; shirt_id?: string; jacket_id?: string | null; reason?: string }> } = {};
    try {
      parsed = JSON.parse(text.match(/\{[\s\S]*\}/)?.[0] ?? "{}");
    } catch {
      /* handled below */
    }

    const outfits: StylistOutfit[] = [];
    for (const o of parsed.outfits ?? []) {
      const shirt = o.shirt_id ? byId.get(o.shirt_id) : undefined;
      if (!shirt || !shirt.category.endsWith("shirt")) continue;
      const ids = [shirt.id];
      const jacket = o.jacket_id ? byId.get(o.jacket_id) : undefined;
      const group = shirt.category.split(" ")[0];
      if (jacket && jacket.category === `${group} jacket`) ids.push(jacket.id);
      outfits.push({ title: (o.title ?? "A considered look").slice(0, 60), reason: (o.reason ?? "").slice(0, 300), itemIds: ids });
      if (outfits.length === 3) break;
    }
    if (outfits.length === 0) throw new Error("AYRA couldn't find a valid look. Please try again.");
    return { outfits };
  });

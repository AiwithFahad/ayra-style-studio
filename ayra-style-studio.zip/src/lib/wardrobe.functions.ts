import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const CATEGORIES = ["Men shirt", "Men jacket", "Kid shirt", "Kid jacket"] as const;
type Category = (typeof CATEGORIES)[number];

export const analyzeAndSaveItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => z.object({ path: z.string().min(1), name: z.string().min(1) }).parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    if (!data.path.startsWith(`${userId}/`)) throw new Error("Invalid photo path.");

    const { data: blob, error: dlError } = await supabase.storage.from("wardrobe").download(data.path);
    if (dlError || !blob) throw new Error("Could not read the uploaded photo.");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const mediaType = blob.type || "image/jpeg";

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI is not configured.");

    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText } = await import("ai");
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });

    let category: Category = "Men shirt";
    let colour = "Unsorted";
    try {
      const result = streamText({
        model: provider.responses("openai/gpt-6-astra"),
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Look at this clothing photo. Classify it into exactly one category: ${CATEGORIES.join(", ")}. Use "Kid" if the garment is child-sized, otherwise "Men". Treat coats, blazers, hoodies and outerwear as jackets; tees, polos and tops as shirts. Also name its main colour in one or two words (e.g. "Navy", "Camel"). Reply with only JSON: {"category": "...", "colour": "..."}`,
              },
              { type: "file", data: bytes, mediaType },
            ],
          },
        ],
        providerOptions: {
          openai: {
            store: false,
            forceReasoning: true,
            reasoningEffort: "low",
            reasoningSummary: "auto",
            include: ["reasoning.encrypted_content"],
          },
        },
      });
      const text = await result.text;
      const match = text.match(/\{[\s\S]*\}/);
      if (match) {
        const parsed = JSON.parse(match[0]) as { category?: string; colour?: string };
        const found = CATEGORIES.find((c) => c.toLowerCase() === parsed.category?.trim().toLowerCase());
        if (found) category = found;
        if (parsed.colour?.trim()) {
          const c = parsed.colour.trim().slice(0, 30);
          colour = c.charAt(0).toUpperCase() + c.slice(1);
        }
      }
    } catch (err) {
      console.error("AI vision failed", err);
      const status = (err as { statusCode?: number })?.statusCode;
      if (status === 402) throw new Error("AI credits are exhausted. Add credits to keep auto-tagging.");
      if (status === 429) throw new Error("AI is busy right now. Please try again in a moment.");
    }

    const { data: row, error: insertError } = await supabase
      .from("wardrobe_items")
      .insert({ user_id: userId, name: data.name.slice(0, 80), category, colour, image_url: data.path })
      .select("id, category, colour")
      .single();
    if (insertError) throw new Error(insertError.message);
    return row;
  });

import type { WardrobeItem } from "@/lib/wardrobe-data";

const PRICE_BY_CATEGORY: Record<WardrobeItem["category"], number> = {
  "Men shirt": 68,
  "Men jacket": 148,
  "Kid shirt": 42,
  "Kid jacket": 84,
};

export function productPrice(item: WardrobeItem) {
  return PRICE_BY_CATEGORY[item.category];
}

export function formatPrice(item: WardrobeItem) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(productPrice(item));
}

export function productGroup(item: WardrobeItem) {
  return item.category.startsWith("Men") ? "Men" : "Kids";
}

export function productType(item: WardrobeItem) {
  return item.category.endsWith("shirt") ? "Shirt" : "Jacket";
}

export function tryOnLookFor(item: WardrobeItem, items: WardrobeItem[]) {
  if (item.category.endsWith("shirt")) return item.id;
  const group = item.category.split(" ")[0];
  const shirt = items.find((candidate) => candidate.category === `${group} shirt`);
  return shirt ? `${shirt.id}~${item.id}` : undefined;
}

import { Link, useRouterState } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Camera, Heart, LogOut, Search, Shirt, ShoppingBag, Sparkles, UserRound } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

const destinations = [
  { to: "/" as const, label: "Wardrobe", icon: Shirt },
  { to: "/stylist" as const, label: "Stylist", icon: Sparkles },
  { to: "/try-on" as const, label: "Try-on", icon: Camera },
];

export function AppShell({ eyebrow, title, note, children, storefront = false }: { eyebrow: string; title: string; note: string; children: ReactNode; storefront?: boolean }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen bg-background text-foreground lg:px-8 lg:py-8">
      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col bg-background lg:min-h-[calc(100vh-4rem)] lg:overflow-hidden lg:rounded-lg lg:shadow-editorial">
        {storefront ? (
          <header className="animate-rise shrink-0 border-b border-border bg-card/70 px-4 sm:px-6 lg:px-10">
            <div className="grid h-16 grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
              <div className="flex min-w-0 items-center gap-8">
                <Link to="/" className="shrink-0 font-display text-2xl leading-none" aria-label="AYRA home">AYRA</Link>
                <nav aria-label="Primary" className="hidden items-center gap-6 text-[11px] font-medium uppercase tracking-[0.12em] md:flex">
                  {destinations.map((item) => <Link key={item.to} to={item.to} className="story-link">{item.label}</Link>)}
                </nav>
              </div>
              <div className="flex shrink-0 items-center gap-0.5">
                <Button asChild variant="ghost" size="icon"><a href="#product-showcase" aria-label="Search products" title="Search products"><Search size={16} /></a></Button>
                <Button asChild variant="ghost" size="icon" className="hidden sm:inline-flex"><a href="#latest-drop" aria-label="Saved pieces" title="Saved pieces"><Heart size={16} /></a></Button>
                <Button asChild variant="ghost" size="icon"><a href="#wardrobe" aria-label="Wardrobe bag" title="Wardrobe bag"><ShoppingBag size={16} /></a></Button>
                <Button variant="ghost" size="icon" onClick={signOut} aria-label="Sign out" title="Sign out"><UserRound size={16} /></Button>
              </div>
            </div>
          </header>
        ) : (
          <header className="animate-rise grid shrink-0 grid-cols-[minmax(0,1fr)_auto] items-end gap-3 px-4 pb-4 pt-5 sm:px-6 sm:pt-7 lg:px-10">
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-[0.3em] text-accent">AYRA · Atelier No. 01</p>
              <h1 className="mt-1 truncate font-display text-[23px] leading-none sm:text-3xl">{title}</h1>
            </div>
            <div className="flex min-w-0 items-center gap-2">
              <p className="hidden max-w-40 text-right text-[11px] leading-tight text-muted-foreground sm:block">{note}</p>
              <Button variant="quiet" size="icon" onClick={signOut} aria-label="Sign out" title="Sign out"><LogOut size={15} /></Button>
            </div>
          </header>
        )}

        {!storefront && <nav aria-label="Primary" className="hidden shrink-0 gap-1 px-6 pb-5 sm:flex lg:px-10">
          {destinations.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={active ? "flex-1 rounded-md bg-card/90 py-2 text-center text-[13px] font-medium ring-1 ring-border" : "flex-1 rounded-md py-2 text-center text-[13px] font-medium text-muted-foreground transition-colors hover:bg-card/60 hover:text-foreground"}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>}

        <main className="flex-1 px-4 pb-28 sm:px-6 sm:pb-10 lg:px-10">
          {!storefront && <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{eyebrow}</p>}
          {children}
        </main>

        <nav aria-label="Mobile navigation" className="fixed inset-x-0 bottom-0 z-30 mx-auto flex w-full justify-around border-t border-border bg-card/90 px-3 py-2.5 backdrop-blur-xl sm:hidden">
          {destinations.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link key={item.to} to={item.to} className={active ? "flex min-w-20 flex-col items-center gap-1 text-foreground" : "flex min-w-20 flex-col items-center gap-1 text-muted-foreground"}>
                <Icon aria-hidden="true" size={18} strokeWidth={1.6} />
                <span className="text-[10px] uppercase tracking-[0.16em]">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Carousel, type CarouselApi, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import { cn } from "@/lib/utils";
import { formatPrice } from "@/lib/product-display";
import type { WardrobeItem } from "@/lib/wardrobe-data";

export function ProductCarousel({ eyebrow, title, items, reverse = false }: { eyebrow: string; title: string; items: WardrobeItem[]; reverse?: boolean }) {
  const [api, setApi] = useState<CarouselApi>();
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (!api) return;
    const update = () => setActive(api.selectedScrollSnap());
    update();
    api.on("select", update);
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") api.scrollNext();
    }, 5200);
    return () => {
      window.clearInterval(timer);
      api.off("select", update);
    };
  }, [api]);

  if (!items.length) return null;
  const displayItems = reverse ? [...items].reverse() : items;

  return (
    <section className="overflow-hidden border-t border-border py-12 sm:py-16" aria-labelledby={`carousel-${title.replace(/\s+/g, "-").toLowerCase()}`}>
      <div className="mb-6 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
        <div className="min-w-0">
          <p className="font-mono text-[9px] uppercase tracking-[0.24em] text-accent">{eyebrow}</p>
          <h2 id={`carousel-${title.replace(/\s+/g, "-").toLowerCase()}`} className="mt-2 text-2xl font-semibold leading-none sm:text-3xl">{title}</h2>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button variant="quiet" size="icon" onClick={() => api?.scrollPrev()} aria-label={`Previous ${title}`} title="Previous"><ArrowLeft size={16} /></Button>
          <Button variant="quiet" size="icon" onClick={() => api?.scrollNext()} aria-label={`Next ${title}`} title="Next"><ArrowRight size={16} /></Button>
        </div>
      </div>
      <Carousel setApi={setApi} opts={{ align: "start", loop: true }} className="[perspective:1200px]">
        <CarouselContent className="-ml-3 py-3">
          {displayItems.map((item, index) => {
            const distance = Math.min(Math.abs(index - active), 2);
            return (
              <CarouselItem key={item.id} className="basis-[72%] pl-3 sm:basis-[38%] lg:basis-[24%] xl:basis-[20%]">
                <Link
                  to="/product/$id"
                  params={{ id: item.id }}
                  className={cn("group block origin-center transition-[transform,opacity] duration-500 ease-out motion-reduce:transform-none", distance === 0 ? "opacity-100 [transform:rotateY(0deg)_translateZ(18px)]" : "opacity-75 [transform:rotateY(3deg)_scale(.96)]")}
                >
                  <article className="overflow-hidden rounded-sm bg-card ring-1 ring-border transition-shadow duration-300 group-hover:shadow-editorial">
                    <div className="overflow-hidden"><img src={item.image} alt={item.name} width={768} height={1024} className="aspect-[3/4] w-full object-cover transition-transform duration-700 group-hover:scale-[1.025] motion-reduce:transform-none" /></div>
                    <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 p-3">
                      <div className="min-w-0"><h3 className="truncate text-sm font-medium">{item.name}</h3><p className="mt-1 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{item.category} · {item.colour}</p></div>
                      <p className="text-sm font-medium">{formatPrice(item)}</p>
                    </div>
                  </article>
                </Link>
              </CarouselItem>
            );
          })}
        </CarouselContent>
      </Carousel>
    </section>
  );
}
